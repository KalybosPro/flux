import 'package:app_api/app_api.dart';

class MainBinding extends Bindings {
  @override
  void dependencies() {
    ApiServiceBinding().dependencies();
  }
}
