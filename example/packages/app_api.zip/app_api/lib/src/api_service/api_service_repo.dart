import 'package:get/get.dart';
import 'api_service_api.dart';
import '../../di/di_container.dart' as di;

class ApiServiceRepo extends GetxService {
  final ApiServiceApi api;
  ApiServiceRepo({required this.api});

  Future<Response> getProduct({int limit=40}) async {
    final url = "${di.resultsUrl}$limit";
    return await api.getProduct(url);
  }
}
