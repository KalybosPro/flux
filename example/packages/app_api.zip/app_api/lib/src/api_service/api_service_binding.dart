import 'package:get/get.dart';
import 'api_service_api.dart';
import 'api_service_repo.dart';
import 'api_service_controller.dart';
import '../../di/di_container.dart' as di;

class ApiServiceBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => ApiServiceApi(appBaseUrl: di.appBaseUrl));
    Get.lazyPut(() => ApiServiceRepo(api: Get.find()));
    Get.lazyPut(() => ApiServiceController(repo: Get.find()));
  }
}
